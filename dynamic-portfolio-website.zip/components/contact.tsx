"use client"

import { useState } from "react"

interface ContactLink {
  platform: string
  icon: string
  url: string
  display: string
}

const contactLinks: ContactLink[] = [
  {
    platform: "Email",
    icon: "✉️",
    url: "mailto:mautidur34@gmail.com",
    display: "mautidur34@gmail.com",
  },
  {
    platform: "GitHub",
    icon: "🔀",
    url: "https://github.com/AbiSulfur",
    display: "github.com/AbiSulfur",
  },
  {
    platform: "LinkedIn",
    icon: "💼",
    url: "https://www.linkedin.com/in/benedictus-abi-66b038345/",
    display: "LinkedIn Profile",
  },
  {
    platform: "Instagram",
    icon: "📸",
    url: "https://www.instagram.com/bened_tri/",
    display: "@bened_tri",
  },
]

export default function Contact() {
  const [copied, setCopied] = useState(false)

  const handleCopyEmail = () => {
    navigator.clipboard.writeText("mautidur34@gmail.com")
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <section id="contact" className="section-padding">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="mb-16 text-center">
          <h2 className="section-title mb-4">Let's Connect</h2>
          <div className="w-16 h-1 bg-accent rounded-full mx-auto"></div>
          <p className="section-subtitle mt-6 max-w-2xl mx-auto">
            I'm interested in internship opportunities, junior developer roles, and collaborating on exciting projects.
            Feel free to reach out—I'd love to hear from you!
          </p>
        </div>

        {/* Contact Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {contactLinks.map((link) => (
            <a
              key={link.platform}
              href={link.url}
              target={link.platform !== "Email" ? "_blank" : undefined}
              rel={link.platform !== "Email" ? "noopener noreferrer" : undefined}
              className="glass-card p-6 hover:border-accent/50 hover:bg-card/80 transition-all duration-300 group"
            >
              <div className="flex items-start gap-4">
                <span className="text-4xl">{link.icon}</span>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground mb-1">{link.platform}</h3>
                  <p className="text-sm text-muted-foreground group-hover:text-accent transition-colors">
                    {link.display}
                  </p>
                </div>
                <span className="text-xl opacity-0 group-hover:opacity-100 transition-opacity">→</span>
              </div>
            </a>
          ))}
        </div>

        {/* Copy Email Button */}
        <div className="bg-card/50 border border-accent/30 rounded-lg p-8 text-center">
          <p className="text-foreground/80 mb-4">Or quickly copy my email:</p>
          <button
            onClick={handleCopyEmail}
            className="inline-block px-6 py-3 bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg font-semibold transition-all duration-300"
          >
            {copied ? "Email Copied!" : "Copy Email Address"}
          </button>
        </div>

        {/* Response Time */}
        <div className="mt-8 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-card/50 rounded-full border border-border/30">
            <span className="w-2 h-2 rounded-full bg-accent animate-pulse"></span>
            <span className="text-sm text-foreground/70">Usually responds within 24 hours</span>
          </div>
        </div>
      </div>
    </section>
  )
}
