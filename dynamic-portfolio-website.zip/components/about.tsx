"use client"

export default function About() {
  return (
    <section id="about" className="section-padding bg-card/30">
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <div className="mb-12">
          <h2 className="section-title mb-4">About Me</h2>
          <div className="w-16 h-1 bg-accent rounded-full"></div>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {/* Left Column: Personal Info */}
          <div className="space-y-6">
            <p className="section-subtitle">
              Hi, I'm <span className="text-foreground font-semibold">Abigail</span> (Benedictus Abigail Triwiyatno), a
              junior web developer currently learning the craft of building functional, clean, and user-friendly web
              applications.
            </p>

            <p className="text-foreground/80 leading-relaxed">
              I'm passionate about understanding how things work on the web—from the basics of HTML and CSS to the logic
              of JavaScript and server-side programming. I believe that every line of code is an opportunity to learn
              and improve.
            </p>

            <p className="text-foreground/80 leading-relaxed">
              Currently, I'm an active student at <span className="text-accent font-semibold">SMK Budi Luhur</span>,
              where I'm building a strong foundation in web technologies. I'm preparing for internships and entry-level
              positions where I can contribute real value and grow alongside experienced developers.
            </p>
          </div>

          {/* Right Column: Quick Facts */}
          <div className="space-y-4">
            <div className="glass-card p-6">
              <h3 className="text-sm uppercase tracking-wider text-accent font-semibold mb-3">Tech Stack</h3>
              <ul className="space-y-2 text-sm text-foreground/80">
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent"></span>
                  Frontend: HTML, CSS, JavaScript, WordPress & Elementor
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent"></span>
                  Backend: PHP, Laravel (MVC, routing, CRUD)
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent"></span>
                  Databases: MySQL, basic SQL queries
                </li>
                <li className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent"></span>
                  Tools: VS Code, Git/GitHub, Chrome DevTools
                </li>
              </ul>
            </div>

            <div className="glass-card p-6">
              <h3 className="text-sm uppercase tracking-wider text-accent font-semibold mb-3">Current Status</h3>
              <p className="text-sm text-foreground/80">
                Active student at SMK Budi Luhur. Looking for internship and junior developer opportunities to apply
                skills in real-world projects.
              </p>
            </div>
          </div>
        </div>

        {/* Motivation / Philosophy */}
        <div className="mt-12 pt-12 border-t border-border/30">
          <p className="text-lg text-foreground/90 leading-relaxed max-w-3xl">
            I approach learning with <span className="highlight">honesty and curiosity</span>—I'm not afraid to say "I
            don't know" and even more excited to figure it out. Every project is a stepping stone, and every mistake is
            a lesson. My goal is to become a full-stack developer who can deliver complete solutions while maintaining
            code quality and respecting user experience.
          </p>
        </div>
      </div>
    </section>
  )
}
