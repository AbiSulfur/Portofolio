"use client"

import { useEffect, useRef } from "react"

interface SkillCategory {
  title: string
  skills: Array<{
    name: string
    icon: string
  }>
}

const skillCategories: SkillCategory[] = [
  {
    title: "Frontend",
    skills: [
      { name: "HTML5", icon: "📄" },
      { name: "CSS3", icon: "🎨" },
      { name: "JavaScript", icon: "⚡" },
      { name: "WordPress", icon: "📝" },
      { name: "Elementor", icon: "🔧" },
    ],
  },
  {
    title: "Backend",
    skills: [
      { name: "PHP", icon: "🐘" },
      { name: "Laravel", icon: "🚀" },
      { name: "MySQL", icon: "💾" },
      { name: "REST APIs", icon: "🌐" },
      { name: "CRUD Operations", icon: "📊" },
    ],
  },
  {
    title: "Tools & Platforms",
    skills: [
      { name: "Git & GitHub", icon: "🔀" },
      { name: "VS Code", icon: "💻" },
      { name: "Chrome DevTools", icon: "🔍" },
      { name: "Postman", icon: "📮" },
      { name: "Terminal/CLI", icon: "⌨️" },
    ],
  },
]

export default function Skills() {
  const scrollContainerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const scrollContainer = scrollContainerRef.current
    if (!scrollContainer) return

    // Clone skills for seamless loop
    const skills = scrollContainer.querySelectorAll("[data-skill]")
    const firstChildClone = scrollContainer.firstElementChild?.cloneNode(true)
    if (firstChildClone) {
      scrollContainer.appendChild(firstChildClone)
    }
  }, [])

  return (
    <section id="skills" className="section-padding">
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <div className="mb-16">
          <h2 className="section-title mb-4">Skills & Technologies</h2>
          <div className="w-16 h-1 bg-accent rounded-full"></div>
          <p className="section-subtitle mt-6 max-w-2xl">
            Here's what I'm comfortable working with. I focus on practical exposure and familiarity with real-world
            tools rather than claiming mastery—I'm always learning.
          </p>
        </div>

        {/* Skill Categories with Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {skillCategories.map((category) => (
            <div key={category.title} className="glass-card p-8 hover:border-accent/40 transition-all duration-300">
              <h3 className="text-lg font-semibold text-accent mb-6">{category.title}</h3>
              <div className="space-y-3">
                {category.skills.map((skill) => (
                  <div key={skill.name} className="flex items-center gap-3 group cursor-default">
                    <span className="text-2xl">{skill.icon}</span>
                    <span className="text-foreground/80 group-hover:text-accent transition-colors">{skill.name}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Auto-scroll Logo Strip Section */}
        <div className="mt-20">
          <h3 className="text-sm uppercase tracking-widest text-muted-foreground font-semibold mb-8 text-center">
            Technology Stack Overview
          </h3>

          {/* Scrolling Container */}
          <div className="relative overflow-hidden bg-card/30 rounded-lg border border-border/30 py-8">
            {/* Gradient Overlays for Edge Effect */}
            <div className="absolute left-0 top-0 bottom-0 w-12 bg-gradient-to-r from-background/80 to-transparent z-10"></div>
            <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-background/80 to-transparent z-10"></div>

            {/* Scrolling Content */}
            <div
              ref={scrollContainerRef}
              className="flex gap-8 px-8 scroll-animation"
              style={{
                width: "max-content",
              }}
            >
              {[
                { name: "HTML5", icon: "📄" },
                { name: "CSS3", icon: "🎨" },
                { name: "JavaScript", icon: "⚡" },
                { name: "PHP", icon: "🐘" },
                { name: "Laravel", icon: "🚀" },
                { name: "MySQL", icon: "💾" },
                { name: "Git", icon: "🔀" },
                { name: "WordPress", icon: "📝" },
                { name: "Elementor", icon: "🔧" },
                { name: "REST APIs", icon: "🌐" },
              ].map((tech, idx) => (
                <div
                  key={`${tech.name}-${idx}`}
                  data-skill
                  className="flex items-center gap-2 px-6 py-3 bg-card/50 border border-border/30 rounded-lg whitespace-nowrap hover:border-accent/50 hover:bg-card transition-all duration-300"
                >
                  <span className="text-xl">{tech.icon}</span>
                  <span className="text-sm font-medium text-foreground">{tech.name}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Info Text */}
          <p className="text-center text-sm text-muted-foreground mt-6">
            Hover over the carousel to pause. New technologies coming soon as I continue learning.
          </p>
        </div>
      </div>
    </section>
  )
}
