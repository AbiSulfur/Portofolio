"use client"

export default function Hero() {
  return (
    <section id="hero" className="min-h-screen flex items-center justify-center pt-20 px-6 md:px-12">
      <div className="max-w-4xl mx-auto text-center">
        {/* Avatar Placeholder */}
        <div className="mb-8 flex justify-center">
          <div className="w-32 h-32 rounded-full bg-gradient-to-br from-accent/30 to-accent/10 border-2 border-accent/30 flex items-center justify-center overflow-hidden">
            <img
              src="/placeholder.svg?height=128&width=128"
              alt="Benedictus Abigail Triwiyatno"
              className="w-full h-full object-cover"
            />
          </div>
        </div>

        {/* Main Headline */}
        <h1 className="section-title mb-4">
          Benedictus Abigail
          <br />
          <span className="highlight">Triwiyatno</span>
        </h1>

        {/* Subtitle */}
        <p className="text-xl md:text-2xl text-muted-foreground mb-4">Junior Web Developer & Student</p>

        {/* Description */}
        <p className="section-subtitle mb-12 max-w-2xl mx-auto">
          Passionate about crafting clean, functional web experiences. Building skills in{" "}
          <span className="highlight">HTML, CSS, JavaScript, PHP,</span> and <span className="highlight">Laravel</span>.
          Currently studying at <span className="text-foreground">SMK Budi Luhur</span>, preparing for growth in web
          development.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button
            onClick={() => document.getElementById("projects")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3 bg-accent hover:bg-accent/90 text-accent-foreground rounded-lg font-semibold transition-colors"
          >
            View My Work
          </button>
          <button
            onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3 bg-card hover:bg-card/80 text-foreground border border-border rounded-lg font-semibold transition-colors"
          >
            Get In Touch
          </button>
        </div>

        {/* Scroll Indicator */}
        <div className="mt-16 flex justify-center animate-bounce">
          <svg className="w-6 h-6 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
          </svg>
        </div>
      </div>
    </section>
  )
}
